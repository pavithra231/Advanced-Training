package Problem14;

import java.util.Scanner;

public class Rectangle {
	
		public float length, width;
		public Rectangle() 
		{
		  length = 1;
		  width = 1;
		 }
		
		 public void perimeter()
		 {
			 System.out.println("perimeter is = "+(length*width)*2);
		 }
		 
		 public void area()
		 {
			 System.out.println("Area is = "+length*width);
		 }
		 
		 public void setValues(float length,float width)
		 {
		  if (length > 0 && length < 20)
		   this.length = length;
		  
		  if (width > 0 && width < 20)
		
		   this.width = width;
		 }
		
		 public void length()
		 {
		  System.out.println("length is = " +length);
		 }
		
		 public void width()
		 {
			 System.out.println("Width is = "+width);
		 }
		 public static void main(String[] args)
		 {
			 Scanner sc = new Scanner(System.in);
			 Rectangle obj=new Rectangle();
			 System.out.print("length :");
			 float length=sc.nextFloat();
			 System.out.print("width :");
			 float width=sc.nextFloat();
			 obj.perimeter();
			 obj.area();
			 obj.setValues(length,width);
			 obj.length();
			 obj.width();
		 }
		 }


