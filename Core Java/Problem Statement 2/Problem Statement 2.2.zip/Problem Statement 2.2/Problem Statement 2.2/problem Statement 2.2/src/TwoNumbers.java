import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    int i = 1, n = 13, first, second;
    try (Scanner sc = new Scanner(System.in)) {
      System.out.println("Enter the first number");
      first = sc.nextInt();
      System.out.println("Enter the second number");
      second = sc.nextInt();
    }
    while (i <= n) {
      System.out.print(first + ", ");

      int next = first + second;
      first = second;
      second = next;
      i++;
    }
  }
}