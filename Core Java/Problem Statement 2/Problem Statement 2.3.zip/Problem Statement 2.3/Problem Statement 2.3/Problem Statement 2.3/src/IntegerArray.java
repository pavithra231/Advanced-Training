import java.util.Arrays;

public class IntegerArray {

	public static void main(String[] args) {
		int[] arr = new int[] { 3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0 };
		int[] copiedArray = Arrays.copyOf(arr, arr.length);
		int total = 0;
		int sum = 0;
		for (int i = 0; i < 14; i++) {
			sum = sum + arr[i];
		}
		arr[15] = sum;

		for (int i = 0; i < arr.length; i++) {
			total = total + arr[i];
		}
		System.out.println("Sum of elements and stored in 15 ");
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
		double average = total / arr.length;
		arr[16] = (int) average;
		System.out.println("Average of elements and stored in 16 ");
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
		Arrays.sort(copiedArray);
		arr[17] = copiedArray[0];
		System.out.println("smallest element and stored in 17 ");
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}
}
