package com.training;

import java.util.*;
import java.util.Map.Entry;
public class PhoneBook
{
    HashMap<String,String> phoneBook=new HashMap<String,String>();
    
    public void addPhoneBook(String name,String contact)
    {
        phoneBook.put(name,contact);
        System.out.println(phoneBook);
        
    }
  
    public void viewContactGivenname(String name)
    {
    	
        for(Entry<String, String> entry: phoneBook.entrySet()) {
          if(entry.getKey() == name) {
            System.out.println("The contact " + name + " is " + entry.getValue());
            
          }
        }
		
    }
    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
        while(true) {
        PhoneBook objmain=new PhoneBook();
          System.out.println("Menu\n1.Add Contact\n2.Search contact by name\n3.Exit");
          System.out.println("Enter your choice: ");
          int n=sc.nextInt();
          switch (n) {
		  case 1: {
			  
              System.out.println("Add a contact: ");
              System.out.println("Enter the Name: ");
              String name=sc.next();
              System.out.println("Enter the contact: ");
              String contact=sc.next();
              objmain.addPhoneBook(name,contact);
              break;	
		 }
		  case 2:{
			  System.out.println("Enter the Phone number to search contact:");
              String n1=sc.next();
              objmain.viewContactGivenname(n1);
              break;
		  }
		  case 3:{
			  System.exit(0);
		  }

           }
        }
    }
}