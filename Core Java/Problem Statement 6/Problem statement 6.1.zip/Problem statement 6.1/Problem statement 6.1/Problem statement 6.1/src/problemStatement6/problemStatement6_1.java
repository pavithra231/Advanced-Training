package problemStatement6;

import java.util.ArrayList;
import java.util.Scanner;

public class problemStatement6_1 {
public static void main(String[] args) {
	ArrayList<String> list = new ArrayList<String>();
	int n ;
	Scanner sc = new Scanner (System.in);
	System.out.println("Enter the number of Student : ");
	n=sc.nextInt();
	System.out.println("Enter Student names : ");
	for(int i=0 ;i<n;i++)
	{
		list.add(sc.next()) ;
	}
	System.out.println("Student list :");
	for (String a:list)
	{
		System.out.println(a);
	}
	System.out.println("Enter the name of student to be searched : ");
	String str =sc.next();
	int a=list.indexOf(str);
	if(a>=0) {
		System.out.println(" Position of "+ str + " is : "+ a );
	}
	else {
		System.out.println("Element is not found");
	}	
}
}
