package net.springboot.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import net.springboot.entity.Product;

public class Test {
public static void main(String[] args) {
//	Resource resource=new ClassPathResource("applicationContext.xml");
//	BeanFactory factory=new XmlBeanFactory(resource);
	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

	Product prod=(Product)context.getBean("product");
	
	System.out.println(prod.toString());
}
}
